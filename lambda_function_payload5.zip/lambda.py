import json
import boto3

def lambda_handler(event, context):


    s3=boto3.client('s3')
    bucketName=event['Records'][0]['s3']['bucket']['name']
    bucketKey=event['Records'][0]['s3']['object']['key']
    response=s3.get_object(Bucket=bucketName,Key=bucketKey)
    data=response['Body'].read()
    text = data.decode('utf-8')
    lines = text.splitlines()
    email_to_msg = {}
    for line in lines:
        email, message = line.split(',', 1)
        email_to_msg[email] = message
    
    client = boto3.client('ses')
    subject ="EmailApp notification contains message from csv"
    responses=[]

    for email in email_to_msg:

        body=email_to_msg[email]
        message={"Subject":{"Data": subject},"Body":{"Html":{"Data":body}}}
        response=client.send_email(
            Source=email,
            Destination={"ToAddresses":[email]},
            Message=message
        )
        responses.append(response)
    print(responses)
    return responses
    
